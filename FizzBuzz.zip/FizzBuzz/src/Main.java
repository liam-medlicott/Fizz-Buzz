import java.util.Scanner;

import week9.in;

public class Main {

	public static void main(String[] args) {
	

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Your Number");
		int myNumber = sc.nextInt();
		
System.out.println("FizzBuzz" + myNumber + " times: ");
		
		for (int i = 1; i <= myNumber; i++) {
			if ((i % 3 == 0) && (i % 5 == 0)) {
				System.out.println(i + " :FizzBuzz");
			}
			else if (i % 3 == 0) {
				System.out.println(i + " :Fizz");
			}
			else if (i % 5 == 0) {
				System.out.println(i +" :Buzz");
			}
		}				
sc.close();
	}
}
		
		
		
		
	
	

